// Sidebar Toggle Functionality//
        let arrow = document.querySelectorAll(".arrow");
        for (let i = 0; i < arrow.length; i++) {
            arrow[i].addEventListener("click", (e) => {
                let arrowParent = e.target.parentElement.parentElement;
                arrowParent.classList.toggle("showMenu");
            });
        }
        
        let sidebar = document.querySelector(".sidebar");
        let sidebarBtn = document.querySelector(".bx-menu");
        sidebarBtn.addEventListener("click", () => {
            sidebar.classList.toggle("close");
        });

//nav predict//
// Data
const data = [
    {
        MT_ID: "807822",
        MT_NAME: "Test Tube Vacutainer 3.2%Sodium citrate 2.7 ml",
        DATE_2024: "2024-01",
        Actual: 5912,
        Hybrid_Forecast_2024: 6479,
        Error: -567.38102,
        AbsError: 567.38102,
        PercentError: 9.597108,
        DATE_2025: "2025-01",
        Hybrid_Forecast_2025: 6706,
        changes: 794,
        changes_percent: 13.42981
    },
    {
        MT_ID: "807822",
        MT_NAME: "Test Tube Vacutainer 3.2%Sodium citrate 2.7 ml",
        DATE_2024: "2024-02",
        Actual: 4807,
        Hybrid_Forecast_2024: 6191,
        Error: -1383.908677,
        AbsError: 1383.9087,
        PercentError: 28.789446,
        DATE_2025: "2025-02",
        Hybrid_Forecast_2025: 6135,
        changes: 1328,
        changes_percent: 27.62761
    },
    {
        MT_ID: "807822",
        MT_NAME: "Test Tube Vacutainer 3.2%Sodium citrate 2.7 ml",
        DATE_2024: "2024-03",
        Actual: 6700,
        Hybrid_Forecast_2024: 6700,
        Error: -0.071714,
        AbsError: 0.071714,
        PercentError: 0.00107,
        DATE_2025: "2025-03",
        Hybrid_Forecast_2025: 6681,
        changes: -19,
        changes_percent: -0.28813
    },
    {
        MT_ID: "807822",
        MT_NAME: "Test Tube Vacutainer 3.2%Sodium citrate 2.7 ml",
        DATE_2024: "2024-04",
        Actual: 6667,
        Hybrid_Forecast_2024: 6667,
        Error: 0.406017,
        AbsError: 0.406017,
        PercentError: 0.00609,
        DATE_2025: "2025-04",
        Hybrid_Forecast_2025: 6036,
        changes: -631,
        changes_percent: -9.46124
    },
    {
        MT_ID: "807822",
        MT_NAME: "Test Tube Vacutainer 3.2%Sodium citrate 2.7 ml",
        DATE_2024: "2024-05",
        Actual: 6516,
        Hybrid_Forecast_2024: 6516,
        Error: 0.056979,
        AbsError: 0.056979,
        PercentError: 0.000874,
        DATE_2025: "2025-05",
        Hybrid_Forecast_2025: 6469,
        changes: -47,
        changes_percent: -0.71472
    },
    {
        MT_ID: "807822",
        MT_NAME: "Test Tube Vacutainer 3.2%Sodium citrate 2.7 ml",
        DATE_2024: "2024-06",
        Actual: 4817,
        Hybrid_Forecast_2024: 4817,
        Error: -0.474106,
        AbsError: 0.474106,
        PercentError: 0.009842,
        DATE_2025: "2025-06",
        Hybrid_Forecast_2025: 5459,
        changes: 642,
        changes_percent: 13.33568
    },
    {
        MT_ID: "807822",
        MT_NAME: "Test Tube Vacutainer 3.2%Sodium citrate 2.7 ml",
        DATE_2024: "2024-07",
        Actual: 6223,
        Hybrid_Forecast_2024: 6223,
        Error: 0.256363,
        AbsError: 0.256363,
        PercentError: 0.004119,
        DATE_2025: "2025-07",
        Hybrid_Forecast_2025: 5871,
        changes: -352,
        changes_percent: -5.65739
    },
    {
        MT_ID: "807822",
        MT_NAME: "Test Tube Vacutainer 3.2%Sodium citrate 2.7 ml",
        DATE_2024: "2024-08",
        Actual: 6786,
        Hybrid_Forecast_2024: 6786,
        Error: 0.086869,
        AbsError: 0.086869,
        PercentError: 0.00128,
        DATE_2025: "2025-08",
        Hybrid_Forecast_2025: 6086,
        changes: -700,
        changes_percent: -10.3114
    },
    {
        MT_ID: "807822",
        MT_NAME: "Test Tube Vacutainer 3.2%Sodium citrate 2.7 ml",
        DATE_2024: "2024-09",
        Actual: 6365,
        Hybrid_Forecast_2024: 6365,
        Error: -0.36393,
        AbsError: 0.36393,
        PercentError: 0.005718,
        DATE_2025: "2025-09",
        Hybrid_Forecast_2025: 6951,
        changes: 586,
        changes_percent: 9.21195
    },
    {
        MT_ID: "807822",
        MT_NAME: "Test Tube Vacutainer 3.2%Sodium citrate 2.7 ml",
        DATE_2024: "2024-10",
        Actual: 6435,
        Hybrid_Forecast_2024: 6435,
        Error: 0.158771,
        AbsError: 0.158771,
        PercentError: 0.002467,
        DATE_2025: "2025-10",
        Hybrid_Forecast_2025: 5710,
        changes: -725,
        changes_percent: -11.2681
    },
    {
        MT_ID: "807822",
        MT_NAME: "Test Tube Vacutainer 3.2%Sodium citrate 2.7 ml",
        DATE_2024: "2024-11",
        Actual: 4959,
        Hybrid_Forecast_2024: 4961,
        Error: -1.883894,
        AbsError: 1.883894,
        PercentError: 0.037989,
        DATE_2025: "2025-11",
        Hybrid_Forecast_2025: 5983,
        changes: 1024,
        changes_percent: 20.65205
    },
    {
        MT_ID: "807822",
        MT_NAME: "Test Tube Vacutainer 3.2%Sodium citrate 2.7 ml",
        DATE_2024: "2024-12",
        Actual: 7050,
        Hybrid_Forecast_2024: 7050,
        Error: 0.311987,
        AbsError: 0.311987,
        PercentError: 0.004425,
        DATE_2025: "2025-12",
        Hybrid_Forecast_2025: 5985,
        changes: -1065,
        changes_percent: -15.1068
    },
    {
        "MT_ID": "807807",
        "MT_NAME": "Test tube Vacutainer Plus K2,6 ML.",
        "DATE_2024": "2024-01",
        "Actual": 8544,
        "Hybrid_Forecast_2024": 10819,
        "Error": -2275.125742,
        "AbsError": 2275.125742,
        "PercentError": 0.26628344,
        "DATE_2025": "2025-01",
        "Hybrid_Forecast_2025": 9097,
        "changes": 553,
        "changes_percent": 6.469680243
    },
    {
        "MT_ID": "807807",
        "MT_NAME": "Test tube Vacutainer Plus K2,6 ML.",
        "DATE_2024": "2024-02",
        "Actual": 10985,
        "Hybrid_Forecast_2024": 11567,
        "Error": -581.893012,
        "AbsError": 581.893012,
        "PercentError": 0.0529716,
        "DATE_2025": "2025-02",
        "Hybrid_Forecast_2025": 11499,
        "changes": 514,
        "changes_percent": 4.674792972
    },
    {
        "MT_ID": "807807",
        "MT_NAME": "Test tube Vacutainer Plus K2,6 ML.",
        "DATE_2024": "2024-03",
        "Actual": 9234,
        "Hybrid_Forecast_2024": 9243,
        "Error": -9.269273,
        "AbsError": 9.269273,
        "PercentError": 0.1000382,
        "DATE_2025": "2025-03",
        "Hybrid_Forecast_2025": 11561,
        "changes": 2327,
        "changes_percent": 25.20094987
    },
    {
        "MT_ID": "807807",
        "MT_NAME": "Test tube Vacutainer Plus K2,6 ML.",
        "DATE_2024": "2024-04",
        "Actual": 10335,
        "Hybrid_Forecast_2024": 10321,
        "Error": 13.621137,
        "AbsError": 13.621137,
        "PercentError": 0.131796,
        "DATE_2025": "2025-04",
        "Hybrid_Forecast_2025": 10135,
        "changes": -200,
        "changes_percent": -1.935149724
    },
    {
        "MT_ID": "807807",
        "MT_NAME": "Test tube Vacutainer Plus K2,6 ML.",
        "DATE_2024": "2024-05",
        "Actual": 8962,
        "Hybrid_Forecast_2024": 8951,
        "Error": 10.733553,
        "AbsError": 10.733553,
        "PercentError": 0.119767,
        "DATE_2025": "2025-05",
        "Hybrid_Forecast_2025": 10418,
        "changes": 1456,
        "changes_percent": 16.24653853
    },
    {
        "MT_ID": "807807",
        "MT_NAME": "Test tube Vacutainer Plus K2,6 ML.",
        "DATE_2024": "2024-06",
        "Actual": 8257,
        "Hybrid_Forecast_2024": 8295,
        "Error": -37.662032,
        "AbsError": 37.662032,
        "PercentError": 0.456122,
        "DATE_2025": "2025-06",
        "Hybrid_Forecast_2025": 10062,
        "changes": 1805,
        "changes_percent": 21.85827815
    },
    {
        "MT_ID": "807807",
        "MT_NAME": "Test tube Vacutainer Plus K2,6 ML.",
        "DATE_2024": "2024-07",
        "Actual": 10306,
        "Hybrid_Forecast_2024": 10248,
        "Error": 58.456392,
        "AbsError": 58.456392,
        "PercentError": 0.567207,
        "DATE_2025": "2025-07",
        "Hybrid_Forecast_2025": 11613,
        "changes": 1307,
        "changes_percent": 12.68172704
    },
    {
        "MT_ID": "807807",
        "MT_NAME": "Test tube Vacutainer Plus K2,6 ML.",
        "DATE_2024": "2024-08",
        "Actual": 8406,
        "Hybrid_Forecast_2024": 8487,
        "Error": -81.052648,
        "AbsError": 81.052648,
        "PercentError": 0.964224,
        "DATE_2025": "2025-08",
        "Hybrid_Forecast_2025": 11376,
        "changes": 2970,
        "changes_percent": 35.32922148
    },
    {
        "MT_ID": "807807",
        "MT_NAME": "Test tube Vacutainer Plus K2,6 ML.",
        "DATE_2024": "2024-09",
        "Actual": 6855,
        "Hybrid_Forecast_2024": 6846,
        "Error": 8.676618,
        "AbsError": 8.676618,
        "PercentError": 0.126442,
        "DATE_2025": "2025-09",
        "Hybrid_Forecast_2025": 10504,
        "changes": 3649,
        "changes_percent": 53.22971624
    },
    {
        "MT_ID": "807807",
        "MT_NAME": "Test tube Vacutainer Plus K2,6 ML.",
        "DATE_2024": "2024-10",
        "Actual": 10430,
        "Hybrid_Forecast_2024": 10434,
        "Error": -3.866605,
        "AbsError": 3.866605,
        "PercentError": 0.037072,
        "DATE_2025": "2025-10",
        "Hybrid_Forecast_2025": 12462,
        "changes": 2032,
        "changes_percent": 19.47829774
    },
    {
        "MT_ID": "807807",
        "MT_NAME": "Test tube Vacutainer Plus K2,6 ML.",
        "DATE_2024": "2024-11",
        "Actual": 9650,
        "Hybrid_Forecast_2024": 9600,
        "Error": 49.582241,
        "AbsError": 49.582241,
        "PercentError": 0.513806,
        "DATE_2025": "2025-11",
        "Hybrid_Forecast_2025": 10629,
        "changes": 979,
        "changes_percent": 10.14208705
    },
    {
        "MT_ID": "807807",
        "MT_NAME": "Test tube Vacutainer Plus K2,6 ML.",
        "DATE_2024": "2024-12",
        "Actual": 12745,
        "Hybrid_Forecast_2024": 12738,
        "Error": 7.228005,
        "AbsError": 7.228005,
        "PercentError": 0.056712,
        "DATE_2025": "2025-12",
        "Hybrid_Forecast_2025": 12631,
        "changes": -114,
        "changes_percent": -0.891225163
    },
    {
        "MT_ID": "807823",
        "MT_NAME": "Tube KF+Na2 EDTA 2 ml with cap (Blood Sugar)Tube glucose",
        "DATE_2024": "2024-01",
        "Actual": 8363,
        "Hybrid_Forecast_2024": 9771,
        "Error": -1408.225902,
        "AbsError": 1408.225902,
        "PercentError": 16.838765,
        "DATE_2025": "2025-01",
        "Hybrid_Forecast_2025": 12446,
        "changes": 4083,
        "changes_percent": 48.82499929
    },
    {
        "MT_ID": "807823",
        "MT_NAME": "Tube KF+Na2 EDTA 2 ml with cap (Blood Sugar)Tube glucose",
        "DATE_2024": "2024-02",
        "Actual": 10388,
        "Hybrid_Forecast_2024": 11279,
        "Error": -891.014936,
        "AbsError": 891.014936,
        "PercentError": 8.577348,
        "DATE_2025": "2025-02",
        "Hybrid_Forecast_2025": 7212,
        "changes": -3176,
        "changes_percent": -30.57376201
    },
    {
        "MT_ID": "807823",
        "MT_NAME": "Tube KF+Na2 EDTA 2 ml with cap (Blood Sugar)Tube glucose",
        "DATE_2024": "2024-03",
        "Actual": 9112,
        "Hybrid_Forecast_2024": 9121,
        "Error": -8.967945,
        "AbsError": 8.967945,
        "PercentError": 0.098419,
        "DATE_2025": "2025-03",
        "Hybrid_Forecast_2025": 10630,
        "changes": 1518,
        "changes_percent": 16.66343817
    },
    {
        "MT_ID": "807823",
        "MT_NAME": "Tube KF+Na2 EDTA 2 ml with cap (Blood Sugar)Tube glucose",
        "DATE_2024": "2024-04",
        "Actual": 9153,
        "Hybrid_Forecast_2024": 9135,
        "Error": 17.822077,
        "AbsError": 17.822077,
        "PercentError": 0.194713,
        "DATE_2025": "2025-04",
        "Hybrid_Forecast_2025": 5810,
        "changes": -3343,
        "changes_percent": -36.51817814
    },
    {
        "MT_ID": "807823",
        "MT_NAME": "Tube KF+Na2 EDTA 2 ml with cap (Blood Sugar)Tube glucose",
        "DATE_2024": "2024-05",
        "Actual": 11880,
        "Hybrid_Forecast_2024": 11881,
        "Error": -1.139203,
        "AbsError": 1.139203,
        "PercentError": 0.009589,
        "DATE_2025": "2025-05",
        "Hybrid_Forecast_2025": 9603,
        "changes": -2277,
        "changes_percent": -19.16762705
    },
    {
        "MT_ID": "807823",
        "MT_NAME": "Tube KF+Na2 EDTA 2 ml with cap (Blood Sugar)Tube glucose",
        "DATE_2024": "2024-06",
        "Actual": 7998,
        "Hybrid_Forecast_2024": 8026,
        "Error": -28.470187,
        "AbsError": 28.470187,
        "PercentError": 0.355966,
        "DATE_2025": "2025-06",
        "Hybrid_Forecast_2025": 7503,
        "changes": -495,
        "changes_percent": -6.192493911
    },
    {
        "MT_ID": "807823",
        "MT_NAME": "Tube KF+Na2 EDTA 2 ml with cap (Blood Sugar)Tube glucose",
        "DATE_2024": "2024-07",
        "Actual": 12537,
        "Hybrid_Forecast_2024": 12523,
        "Error": 14.082179,
        "AbsError": 14.082179,
        "PercentError": 0.112325,
        "DATE_2025": "2025-07",
        "Hybrid_Forecast_2025": 8728,
        "changes": -3809,
        "changes_percent": -30.37967646
    },
    {
        "MT_ID": "807823",
        "MT_NAME": "Tube KF+Na2 EDTA 2 ml with cap (Blood Sugar)Tube glucose",
        "DATE_2024": "2024-08",
        "Actual": 8689,
        "Hybrid_Forecast_2024": 8678,
        "Error": 11.260374,
        "AbsError": 11.260374,
        "PercentError": 0.129593,
        "DATE_2025": "2025-08",
        "Hybrid_Forecast_2025": 9972,
        "changes": 1283,
        "changes_percent": 14.76558582
    },
    {
        "MT_ID": "807823",
        "MT_NAME": "Tube KF+Na2 EDTA 2 ml with cap (Blood Sugar)Tube glucose",
        "DATE_2024": "2024-09",
        "Actual": 8592,
        "Hybrid_Forecast_2024": 8610,
        "Error": -17.878644,
        "AbsError": 17.878644,
        "PercentError": 0.208085,
        "DATE_2025": "2025-09",
        "Hybrid_Forecast_2025": 9964,
        "changes": 1372,
        "changes_percent": 15.97012547
    },
    {
        "MT_ID": "807823",
        "MT_NAME": "Tube KF+Na2 EDTA 2 ml with cap (Blood Sugar)Tube glucose",
        "DATE_2024": "2024-10",
        "Actual": 11572,
        "Hybrid_Forecast_2024": 11573,
        "Error": -0.946349,
        "AbsError": 0.946349,
        "PercentError": 0.008178,
        "DATE_2025": "2025-10",
        "Hybrid_Forecast_2025": 8910,
        "changes": -2662,
        "changes_percent": -23.00326167
    },
    {
        "MT_ID": "807823",
        "MT_NAME": "Tube KF+Na2 EDTA 2 ml with cap (Blood Sugar)Tube glucose",
        "DATE_2024": "2024-11",
        "Actual": 9531,
        "Hybrid_Forecast_2024": 9512,
        "Error": 18.656137,
        "AbsError": 18.656137,
        "PercentError": 0.195742,
        "DATE_2025": "2025-11",
        "Hybrid_Forecast_2025": 10189,
        "changes": 658,
        "changes_percent": 6.905026041
    },
    {
        "MT_ID": "807823",
        "MT_NAME": "Tube KF+Na2 EDTA 2 ml with cap (Blood Sugar)Tube glucose",
        "DATE_2024": "2024-12",
        "Actual": 8412,
        "Hybrid_Forecast_2024": 8421,
        "Error": -8.707196,
        "AbsError": 8.707196,
        "PercentError": 0.103509,
        "DATE_2025": "2025-12",
        "Hybrid_Forecast_2025": 10013,
        "changes": 1601,
        "changes_percent": 19.02941702
    },
    {
        "MT_ID": "940004",
        "MT_NAME": "Tube stuart trasport media",
        "DATE_2024": "2024-01",
        "Actual": 586,
        "Hybrid_Forecast_2024": 588,
        "Error": -1.597504,
        "AbsError": 1.597504,
        "PercentError": 0.272612,
        "DATE_2025": "2025-01",
        "Hybrid_Forecast_2025": 586,
        "changes": 0,
        "changes_percent": -0.028318601
    },
    {
        "MT_ID": "940004",
        "MT_NAME": "Tube stuart trasport media",
        "DATE_2024": "2024-02",
        "Actual": 562,
        "Hybrid_Forecast_2024": 560,
        "Error": 1.534755,
        "AbsError": 1.534755,
        "PercentError": 0.273088,
        "DATE_2025": "2025-02",
        "Hybrid_Forecast_2025": 576,
        "changes": 14,
        "changes_percent": 2.509686299
    },
    {
        "MT_ID": "940004",
        "MT_NAME": "Tube stuart trasport media",
        "DATE_2024": "2024-03",
        "Actual": 629,
        "Hybrid_Forecast_2024": 630,
        "Error": -0.811653,
        "AbsError": 0.811653,
        "PercentError": 0.129039,
        "DATE_2025": "2025-03",
        "Hybrid_Forecast_2025": 621,
        "changes": -8,
        "changes_percent": -1.334377583
    },
    {
        "MT_ID": "940004",
        "MT_NAME": "Tube stuart trasport media",
        "DATE_2024": "2024-04",
        "Actual": 631,
        "Hybrid_Forecast_2024": 630,
        "Error": 1.498829,
        "AbsError": 1.498829,
        "PercentError": 0.237532,
        "DATE_2025": "2025-04",
        "Hybrid_Forecast_2025": 544,
        "changes": -87,
        "changes_percent": -13.72766482
    },
    {
        "MT_ID": "940004",
        "MT_NAME": "Tube stuart trasport media",
        "DATE_2024": "2024-05",
        "Actual": 601,
        "Hybrid_Forecast_2024": 601,
        "Error": -0.246382,
        "AbsError": 0.246382,
        "PercentError": 0.040995,
        "DATE_2025": "2025-05",
        "Hybrid_Forecast_2025": 591,
        "changes": -10,
        "changes_percent": -1.673511148
    },
    {
        "MT_ID": "940004",
        "MT_NAME": "Tube stuart trasport media",
        "DATE_2024": "2024-06",
        "Actual": 393,
        "Hybrid_Forecast_2024": 394,
        "Error": -1.188179,
        "AbsError": 1.188179,
        "PercentError": 0.302336,
        "DATE_2025": "2025-06",
        "Hybrid_Forecast_2025": 404,
        "changes": 11,
        "changes_percent": 2.70686056
    },
    {
        "MT_ID": "940004",
        "MT_NAME": "Tube stuart trasport media",
        "DATE_2024": "2024-07",
        "Actual": 523,
        "Hybrid_Forecast_2024": 522,
        "Error": 1.334174,
        "AbsError": 1.334174,
        "PercentError": 0.255106,
        "DATE_2025": "2025-07",
        "Hybrid_Forecast_2025": 505,
        "changes": -18,
        "changes_percent": -3.417608222
    },
    {
        "MT_ID": "940004",
        "MT_NAME": "Tube stuart trasport media",
        "DATE_2024": "2024-08",
        "Actual": 411,
        "Hybrid_Forecast_2024": 411,
        "Error": 0.030643,
        "AbsError": 0.030643,
        "PercentError": 0.007456,
        "DATE_2025": "2025-08",
        "Hybrid_Forecast_2025": 414,
        "changes": 3,
        "changes_percent": 0.767430657
    },
    {
        "MT_ID": "940004",
        "MT_NAME": "Tube stuart trasport media",
        "DATE_2024": "2024-09",
        "Actual": 345,
        "Hybrid_Forecast_2024": 347,
        "Error": -2.179305,
        "AbsError": 2.179305,
        "PercentError": 0.631683,
        "DATE_2025": "2025-09",
        "Hybrid_Forecast_2025": 421,
        "changes": 76,
        "changes_percent": 22.12734783
    },
    {
        "MT_ID": "940004",
        "MT_NAME": "Tube stuart trasport media",
        "DATE_2024": "2024-10",
        "Actual": 465,
        "Hybrid_Forecast_2024": 465,
        "Error": -0.034855,
        "AbsError": 0.034855,
        "PercentError": 0.007496,
        "DATE_2025": "2025-10",
        "Hybrid_Forecast_2025": 445,
        "changes": -20,
        "changes_percent": -4.250467742
    },
    {
        "MT_ID": "940004",
        "MT_NAME": "Tube stuart trasport media",
        "DATE_2024": "2024-11",
        "Actual": 439,
        "Hybrid_Forecast_2024": 438,
        "Error": 1.079871,
        "AbsError": 1.079871,
        "PercentError": 0.245984,
        "DATE_2025": "2025-11",
        "Hybrid_Forecast_2025": 446,
        "changes": 7,
        "changes_percent": 1.608288838
    },
    {
        "MT_ID": "940004",
        "MT_NAME": "Tube stuart trasport media",
        "DATE_2024": "2024-12",
        "Actual": 470,
        "Hybrid_Forecast_2024": 470,
        "Error": -0.120447,
        "AbsError": 0.120447,
        "PercentError": 0.025627,
        "DATE_2025": "2025-12",
        "Hybrid_Forecast_2025": 488,
        "changes": 18,
        "changes_percent": 3.838389362
    },
    {
        "MT_ID": "807816",
        "MT_NAME": "Tube vacuum EDTA k2, 2 ml",
        "DATE_2024": "2024-01",
        "Actual": 29419,
        "Hybrid_Forecast_2024": 27060,
        "Error": 2359.459953,
        "AbsError": 2359.459953,
        "PercentError": 8.020191,
        "DATE_2025": "2025-01",
        "Hybrid_Forecast_2025": 28324,
        "changes": -1095,
        "changes_percent": -3.721209654
    },
    {
        "MT_ID": "807816",
        "MT_NAME": "Tube vacuum EDTA k2, 2 ml",
        "DATE_2024": "2024-02",
        "Actual": 29081,
        "Hybrid_Forecast_2024": 27562,
        "Error": 1518.82397,
        "AbsError": 1518.82397,
        "PercentError": 5.222736,
        "DATE_2025": "2025-02",
        "Hybrid_Forecast_2025": 27140,
        "changes": -1941,
        "changes_percent": -6.674387934
    },
    {
        "MT_ID": "807816",
        "MT_NAME": "Tube vacuum EDTA k2, 2 ml",
        "DATE_2024": "2024-03",
        "Actual": 26975,
        "Hybrid_Forecast_2024": 26983,
        "Error": -7.922972,
        "AbsError": 7.922972,
        "PercentError": 0.029372,
        "DATE_2025": "2025-03",
        "Hybrid_Forecast_2025": 29447,
        "changes": 2472,
        "changes_percent": 9.16540063
    },
    {
        "MT_ID": "807816",
        "MT_NAME": "Tube vacuum EDTA k2, 2 ml",
        "DATE_2024": "2024-04",
        "Actual": 29155,
        "Hybrid_Forecast_2024": 29157,
        "Error": -1.975406,
        "AbsError": 1.975406,
        "PercentError": 0.006776,
        "DATE_2025": "2025-04",
        "Hybrid_Forecast_2025": 20405,
        "changes": -8750,
        "changes_percent": -30.01368522
    },
    {
        "MT_ID": "807816",
        "MT_NAME": "Tube vacuum EDTA k2, 2 ml",
        "DATE_2024": "2024-05",
        "Actual": 30120,
        "Hybrid_Forecast_2024": 30076,
        "Error": 44.424744,
        "AbsError": 44.424744,
        "PercentError": 0.147493,
        "DATE_2025": "2025-05",
        "Hybrid_Forecast_2025": 27176,
        "changes": -2944,
        "changes_percent": -9.772720037
    },
    {
        "MT_ID": "807816",
        "MT_NAME": "Tube vacuum EDTA k2, 2 ml",
        "DATE_2024": "2024-06",
        "Actual": 26222,
        "Hybrid_Forecast_2024": 26222,
        "Error": -0.103141,
        "AbsError": 0.103141,
        "PercentError": 0.000393,
        "DATE_2025": "2025-06",
        "Hybrid_Forecast_2025": 25695,
        "changes": -527,
        "changes_percent": -2.008359263
    },
    {
        "MT_ID": "807816",
        "MT_NAME": "Tube vacuum EDTA k2, 2 ml",
        "DATE_2024": "2024-07",
        "Actual": 32310,
        "Hybrid_Forecast_2024": 32313,
        "Error": -2.694642,
        "AbsError": 2.694642,
        "PercentError": 0.00834,
        "DATE_2025": "2025-07",
        "Hybrid_Forecast_2025": 28142,
        "changes": -4168,
        "changes_percent": -12.90042292
    },
    {
        "MT_ID": "807816",
        "MT_NAME": "Tube vacuum EDTA k2, 2 ml",
        "DATE_2024": "2024-08",
        "Actual": 28293,
        "Hybrid_Forecast_2024": 28302,
        "Error": -8.696781,
        "AbsError": 8.696781,
        "PercentError": 0.307378,
        "DATE_2025": "2025-08",
        "Hybrid_Forecast_2025": 27259,
        "changes": -1034,
        "changes_percent": -3.65310844
    },
    {
        "MT_ID": "807816",
        "MT_NAME": "Tube vacuum EDTA k2, 2 ml",
        "DATE_2024": "2024-09",
        "Actual": 27042,
        "Hybrid_Forecast_2024": 27128,
        "Error": -85.695593,
        "AbsError": 85.695593,
        "PercentError": 0.316899,
        "DATE_2025": "2025-09",
        "Hybrid_Forecast_2025": 29881,
        "changes": 2839,
        "changes_percent": 10.49816836
    },
    {
        "MT_ID": "807816",
        "MT_NAME": "Tube vacuum EDTA k2, 2 ml",
        "DATE_2024": "2024-10",
        "Actual": 32678,
        "Hybrid_Forecast_2024": 32633,
        "Error": 44.644106,
        "AbsError": 44.644106,
        "PercentError": 0.136618,
        "DATE_2025": "2025-10",
        "Hybrid_Forecast_2025": 27588,
        "changes": -5090,
        "changes_percent": -15.5768228
    },
    {
        "MT_ID": "807816",
        "MT_NAME": "Tube vacuum EDTA k2, 2 ml",
        "DATE_2024": "2024-11",
        "Actual": 28675,
        "Hybrid_Forecast_2024": 28724,
        "Error": -48.950608,
        "AbsError": 48.950608,
        "PercentError": 0.170708,
        "DATE_2025": "2025-11",
        "Hybrid_Forecast_2025": 29778,
        "changes": 1103,
        "changes_percent": 3.845142636
    },
    {
        "MT_ID": "807816",
        "MT_NAME": "Tube vacuum EDTA k2, 2 ml",
        "DATE_2024": "2024-12",
        "Actual": 29747,
        "Hybrid_Forecast_2024": 29731,
        "Error": 16.366643,
        "AbsError": 16.366643,
        "PercentError": 0.055019,
        "DATE_2025": "2025-12",
        "Hybrid_Forecast_2025": 29668,
        "changes": -79,
        "changes_percent": -0.266510899
    },
    {
        "MT_ID": "995001",
        "MT_NAME": "ขวดอาหารเลี้ยงเชื้อสำหรับผู้ใหญ่",
        "DATE_2024": "2024-01",
        "Actual": 2443,
        "Hybrid_Forecast_2024": 2516,
        "Error": -73.026882,
        "AbsError": 73.026882,
        "PercentError": 2.98923,
        "DATE_2025": "2025-01",
        "Hybrid_Forecast_2025": 2524,
        "changes": 81,
        "changes_percent": 3.316729349
    },
    {
        "MT_ID": "995001",
        "MT_NAME": "ขวดอาหารเลี้ยงเชื้อสำหรับผู้ใหญ่",
        "DATE_2024": "2024-02",
        "Actual": 2568,
        "Hybrid_Forecast_2024": 2670,
        "Error": -102.3455519,
        "AbsError": 102.3455519,
        "PercentError": 3.985417,
        "DATE_2025": "2025-02",
        "Hybrid_Forecast_2025": 2467,
        "changes": -101,
        "changes_percent": -3.913678037
    },
    {
        "MT_ID": "995001",
        "MT_NAME": "ขวดอาหารเลี้ยงเชื้อสำหรับผู้ใหญ่",
        "DATE_2024": "2024-03",
        "Actual": 2548,
        "Hybrid_Forecast_2024": 2548,
        "Error": -0.4100047,
        "AbsError": 0.4100047,
        "PercentError": 0.016093,
        "DATE_2025": "2025-03",
        "Hybrid_Forecast_2025": 2576,
        "changes": 28,
        "changes_percent": 1.086259223
    },
    {
        "MT_ID": "995001",
        "MT_NAME": "ขวดอาหารเลี้ยงเชื้อสำหรับผู้ใหญ่",
        "DATE_2024": "2024-04",
        "Actual": 2452,
        "Hybrid_Forecast_2024": 2446,
        "Error": 5.194647,
        "AbsError": 5.194647,
        "PercentError": 0.211853,
        "DATE_2025": "2025-04",
        "Hybrid_Forecast_2025":2228,
        "changes": -224,
        "changes_percent": -9.115572512
    },
    {
        "MT_ID": "995001",
        "MT_NAME": "ขวดอาหารเลี้ยงเชื้อสำหรับผู้ใหญ่",
        "DATE_2024": "2024-05",
        "Actual": 2746,
        "Hybrid_Forecast_2024": 2748,
        "Error": -2.370214,
        "AbsError": 2.370214,
        "PercentError": 0.086315,
        "DATE_2025": "2025-05",
        "Hybrid_Forecast_2025": 2391,
        "changes": -355,
        "changes_percent": -12.91671755
    },
    {
        "MT_ID": "995001",
        "MT_NAME": "ขวดอาหารเลี้ยงเชื้อสำหรับผู้ใหญ่",
        "DATE_2024": "2024-06",
        "Actual": 2410,
        "Hybrid_Forecast_2024": 2415,
        "Error": -5.085544,
        "AbsError": 5.085544,
        "PercentError": 0.211018,
        "DATE_2025": "2025-06",
        "Hybrid_Forecast_2025": 2196,
        "changes": -214,
        "changes_percent": -8.87553917
    },
    {
        "MT_ID": "995001",
        "MT_NAME": "ขวดอาหารเลี้ยงเชื้อสำหรับผู้ใหญ่",
        "DATE_2024": "2024-07",
        "Actual": 2859,
        "Hybrid_Forecast_2024": 2859,
        "Error": 0.439072,
        "AbsError": 0.439072,
        "PercentError": 0.015358,
        "DATE_2025": "2025-07",
        "Hybrid_Forecast_2025": 2563,
        "changes": -296,
        "changes_percent": -10.35458678
    },
    {
        "MT_ID": "995001",
        "MT_NAME": "ขวดอาหารเลี้ยงเชื้อสำหรับผู้ใหญ่",
        "DATE_2024": "2024-08",
        "Actual": 2708,
        "Hybrid_Forecast_2024": 2701,
        "Error": 6.681442,
        "AbsError": 6.681442,
        "PercentError": 0.24673,
        "DATE_2025": "2025-08",
        "Hybrid_Forecast_2025": 2581,
        "changes": -127,
        "changes_percent": -4.702314476
    },
    {
        "MT_ID": "995001",
        "MT_NAME": "ขวดอาหารเลี้ยงเชื้อสำหรับผู้ใหญ่",
        "DATE_2024": "2024-09",
        "Actual": 2533,
        "Hybrid_Forecast_2024": 2534,
        "Error": -1.217802,
        "AbsError": 1.217802,
        "PercentError": 0.048077,
        "DATE_2025": "2025-09",
        "Hybrid_Forecast_2025": 2527,
        "changes": -6,
        "changes_percent": -0.224224753
    },
    {
        "MT_ID": "995001",
        "MT_NAME": "ขวดอาหารเลี้ยงเชื้อสำหรับผู้ใหญ่",
        "DATE_2024": "2024-10",
        "Actual": 2267,
        "Hybrid_Forecast_2024": 2270,
        "Error": -3.444729,
        "AbsError": 3.444729,
        "PercentError": 0.151951,
        "DATE_2025": "2025-10",
        "Hybrid_Forecast_2025": 2534,
        "changes": 267,
        "changes_percent": 11.76211319
    },
    {
        "MT_ID": "995001",
        "MT_NAME": "ขวดอาหารเลี้ยงเชื้อสำหรับผู้ใหญ่",
        "DATE_2024": "2024-11",
        "Actual": 2917,
        "Hybrid_Forecast_2024": 2913,
        "Error": 4.721381,
        "AbsError": 4.721381,
        "PercentError": 0.161857,
        "DATE_2025": "2025-11",
        "Hybrid_Forecast_2025": 2444,
        "changes": -473,
        "changes_percent": -16.20602636
    },
    {
        "MT_ID": "995001",
        "MT_NAME": "ขวดอาหารเลี้ยงเชื้อสำหรับผู้ใหญ่",
        "DATE_2024": "2024-12",
        "Actual": 2606,
        "Hybrid_Forecast_2024": 2608,
        "Error": -2.160083,
        "AbsError": 2.160083,
        "PercentError": 0.082889,
        "DATE_2025": "2025-12",
        "Hybrid_Forecast_2025": 2649,
        "changes": 43,
        "changes_percent": 1.658197199
    }
];

// Extract months for x-axis
const months = data.map(item => {
    const date = item.DATE_2024.split('-')[1];
    return getMonthName(date);
});

// Extract data for charts
const actualValues = data.map(item => item.Actual);
const forecast2024Values = data.map(item => item.Hybrid_Forecast_2024);
const forecast2025Values = data.map(item => item.Hybrid_Forecast_2025);
const changesValues = data.map(item => item.changes);
const changesPercentValues = data.map(item => item.changes_percent);
const percentErrorValues = data.map(item => item.PercentError);

// Calculate summary statistics
const avgActual = (actualValues.reduce((a, b) => a + b, 0) / actualValues.length).toFixed(0);
const avgForecast2025 = (forecast2025Values.reduce((a, b) => a + b, 0) / forecast2025Values.length).toFixed(0);
const maxError = Math.max(...percentErrorValues).toFixed(2);

// Update summary cards
document.getElementById('avgActual').textContent = avgActual;
document.getElementById('avgForecast2025').textContent = avgForecast2025;
document.getElementById('maxError').textContent = maxError + '%';

// Function to get month name from number
function getMonthName(monthNum) {
    const months = [
        'Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun',
        'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'
    ];
    return months[parseInt(monthNum) - 1];
}

// Register controllers, elements, scales and plugins
Chart.defaults.font.family = "'Segoe UI', Tahoma, Geneva, Verdana, sans-serif";
Chart.defaults.color = "#5a3d8a";
Chart.defaults.scale.grid.color = "rgba(0, 0, 0, 0.05)";

// Create Forecast 2025 Chart with Changes
const forecastCtx = document.getElementById('forecastChart').getContext('2d');
const forecastChart = new Chart(forecastCtx, {
    type: 'bar',
    data: {
        labels: months,
        datasets: [
            {
                label: 'Hybrid Forecast 2025',
                data: forecast2025Values,
                backgroundColor: 'rgba(115, 186, 155, 0.7)',
                borderColor: 'rgba(115, 186, 155, 1)',
                borderWidth: 1,
                order: 1,
                yAxisID: 'y'
            },
            {
                label: 'Changes',
                data: changesValues,
                type: 'line',
                borderColor: 'rgba(90, 61, 138, 0.8)',
                borderWidth: 2,
                pointBackgroundColor: 'rgba(90, 61, 138, 0.8)',
                pointRadius: 4,
                fill: false,
                order: 0,
                yAxisID: 'y1'
            },
            {
                label: 'Changes (%)',
                data: changesPercentValues,
                type: 'line',
                borderColor: 'rgba(255, 99, 132, 0.8)',
                borderWidth: 2,
                pointBackgroundColor: 'rgba(255, 99, 132, 0.8)',
                pointRadius: 4,
                pointStyle: 'triangle',
                fill: false,
                order: 0,
                yAxisID: 'y1'
            }
        ]
    },
    options: {
        responsive: true,
        maintainAspectRatio: false,
        plugins: {
            legend: {
                position: 'top',
            },
            tooltip: {
                mode: 'index',
                intersect: false,
            }
        },
        scales: {
            y: {
                type: 'linear',
                display: true,
                position: 'left',
                title: {
                    display: true,
                    text: 'Forecast Units'
                },
                grid: {
                    drawOnChartArea: false
                }
            },
            y1: {
                type: 'linear',
                display: true,
                position: 'right',
                title: {
                    display: true,
                    text: 'Changes'
                },
                grid: {
                    drawOnChartArea: false
                }
            },
            x: {
                title: {
                    display: true,
                    text: 'Month'
                }
            }
        }
    }
});

// Create Actual vs Forecast 2024 Chart
const compareCtx = document.getElementById('compareChart').getContext('2d');
const compareChart = new Chart(compareCtx, {
    type: 'line',
    data: {
        labels: months,
        datasets: [
            {
                label: 'Actual 2024',
                data: actualValues,
                borderColor: 'rgba(115, 186, 155, 1)',
                backgroundColor: 'rgba(115, 186, 155, 0.1)',
                borderWidth: 2,
                pointBackgroundColor: 'rgba(115, 186, 155, 1)',
                pointRadius: 4,
                fill: false
            },
            {
                label: 'Hybrid Forecast 2024',
                data: forecast2024Values,
                borderColor: 'rgba(132, 94, 194, 1)',
                backgroundColor: 'rgba(132, 94, 194, 0.1)',
                borderWidth: 2,
                pointBackgroundColor: 'rgba(132, 94, 194, 1)',
                pointRadius: 4,
                pointStyle: 'triangle',
                fill: false
            }
        ]
    },
    options: {
        responsive: true,
        maintainAspectRatio: false,
        plugins: {
            legend: {
                position: 'top',
            },
            tooltip: {
                mode: 'index',
                intersect: false,
            }
        },
        scales: {
            y: {
                title: {
                    display: true,
                    text: 'Units'
                },
                beginAtZero: false
            },
            x: {
                title: {
                    display: true,
                    text: 'Month'
                }
            }
        }
    }
});

// Create Error Chart
const errorCtx = document.getElementById('errorChart').getContext('2d');
const errorChart = new Chart(errorCtx, {
    type: 'bar',
    data: {
        labels: months,
        datasets: [
            {
                label: 'Percentage Error (%)',
                data: percentErrorValues,
                backgroundColor: function(context) {
                    const value = context.dataset.data[context.dataIndex];
                    return value > 10 ? 'rgba(220, 53, 69, 0.7)' : 'rgba(115, 186, 155, 0.7)';
                },
                borderColor: function(context) {
                    const value = context.dataset.data[context.dataIndex];
                    return value > 10 ? 'rgba(220, 53, 69, 1)' : 'rgba(115, 186, 155, 1)';
                },
                borderWidth: 1
            }
        ]
    },
    options: {
        responsive: true,
        maintainAspectRatio: false,
        plugins: {
            legend: {
                position: 'top',
            },
            tooltip: {
                callbacks: {
                    label: function(context) {
                        return `Error: ${context.raw.toFixed(2)}%`;
                    }
                }
            }
        },
        scales: {
            y: {
                title: {
                    display: true,
                    text: 'Error (%)'
                }
            },
            x: {
                title: {
                    display: true,
                    text: 'Month'
                }
            }
        }
    }
});

// Event listener for material selection
// Function to filter data by MT_ID
function filterDataByMTID(mtId) {
    return data.filter(item => item.MT_ID === mtId);
}

// Function to update chart data and render
function updateCharts(filteredData) {
    const months = filteredData.map(item => getMonthName(item.DATE_2024.split('-')[1]));
    const actualValues = filteredData.map(item => item.Actual);
    const forecast2024Values = filteredData.map(item => item.Hybrid_Forecast_2024);
    const forecast2025Values = filteredData.map(item => item.Hybrid_Forecast_2025);
    const changesValues = filteredData.map(item => item.changes);
    const changesPercentValues = filteredData.map(item => item.changes_percent);
    const percentErrorValues = filteredData.map(item => item.PercentError);

    // Update summary statistics
    const avgActual = (actualValues.reduce((a, b) => a + b, 0) / actualValues.length).toFixed(0);
    const avgForecast2025 = (forecast2025Values.reduce((a, b) => a + b, 0) / forecast2025Values.length).toFixed(0);
    const maxError = Math.max(...percentErrorValues).toFixed(2);

    document.getElementById('avgActual').textContent = avgActual;
    document.getElementById('avgForecast2025').textContent = avgForecast2025;
    document.getElementById('maxError').textContent = maxError + '%';

    // Update charts
    forecastChart.data.labels = months;
    forecastChart.data.datasets[0].data = forecast2025Values;
    forecastChart.data.datasets[1].data = changesValues;
    forecastChart.data.datasets[2].data = changesPercentValues;

    compareChart.data.labels = months;
    compareChart.data.datasets[0].data = actualValues;
    compareChart.data.datasets[1].data = forecast2024Values;

    errorChart.data.labels = months;
    errorChart.data.datasets[0].data = percentErrorValues;

    forecastChart.update();
    compareChart.update();
    errorChart.update();
}

// Register event listener for material selection
document.getElementById('mtNameSelect').addEventListener('change', function() {
    const selectedMtId = this.value;
    const filteredData = filterDataByMTID(selectedMtId);
    updateCharts(filteredData);
});

window.onload = function () {
    const initialMtId = '807822'; 
    const initialData = filterDataByMTID(initialMtId);
    updateCharts(initialData);
};