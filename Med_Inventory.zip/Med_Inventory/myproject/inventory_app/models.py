import pandas as pd
from django.db import connection

def get_top_items():
    try:
        with connection.cursor() as cursor:
            cursor.execute("""
                SELECT 
                    MT_ID,
                    MT_NAME,
                    EXTRACT(YEAR FROM APP_DATE) AS OrderYear,
                    EXTRACT(MONTH FROM APP_DATE) AS OrderMonth,
                    SUM(PAY_QTY) AS Total_PAY_QTY
                FROM 
                    db_inventory.usemt36404
                WHERE 
                    MT_ID IN ('995001', '807816', '040120', '807807', '940009', '807823', '807822', '940004')
                    AND APP_DATE BETWEEN '2015-01-01' AND '2024-12-31'
                    AND PAY_QTY > 0
                GROUP BY 
                    MT_ID,
                    MT_NAME,
                    EXTRACT(YEAR FROM APP_DATE),
                    EXTRACT(MONTH FROM APP_DATE)
                ORDER BY 
                    MT_ID,
                    OrderYear,
                    OrderMonth;
            """)
            rows = cursor.fetchall()
            columns = [col[0] for col in cursor.description]
            df = pd.DataFrame(rows, columns=columns)
        return df
    except Exception as e:
        print(f"Error in get_top_items: {e}")
        return pd.DataFrame()  

#function for dashboard   
def get_cleaned_inventory_data(start_date='2020-01-01', end_date='2024-12-31'):
    """ดึงข้อมูลที่ผ่านการกรองและทำความสะอาดแล้ว"""
    try:
        with connection.cursor() as cursor:
            sql = """
                SELECT DISTINCT 
                    MT_ID,
                    MT_NAME,
                    Com_code,
                    COM_NAME,
                    PAY_QTY,
                    MT_MONEY,
                    APP_DATE
                FROM 
                    db_inventory.usemt36404
                WHERE 
                    APP_DATE BETWEEN %s AND %s
                    AND PAY_QTY <> 0
                    AND MT_MONEY <> 0
                    AND MT_ID IS NOT NULL AND MT_ID <> ''
                    AND MT_NAME IS NOT NULL AND MT_NAME <> ''
                    AND Com_code IS NOT NULL AND Com_code <> ''
                    AND COM_NAME IS NOT NULL AND COM_NAME <> ''
                    AND PAY_QTY IS NOT NULL
                    AND MT_MONEY IS NOT NULL
                    AND APP_DATE IS NOT NULL;
            """
            cursor.execute(sql, [start_date, end_date])
            rows = cursor.fetchall()
            columns = [desc[0] for desc in cursor.description]
            df = pd.DataFrame(rows, columns=columns)

            # แปลงประเภทข้อมูล
            df['PAY_QTY'] = pd.to_numeric(df['PAY_QTY'], errors='coerce')
            df['MT_MONEY'] = pd.to_numeric(df['MT_MONEY'], errors='coerce')
            df['APP_DATE'] = pd.to_datetime(df['APP_DATE'], errors='coerce')

            # ลบแถวที่ไม่พร้อมใช้งาน
            df = df.dropna(subset=['PAY_QTY', 'MT_MONEY', 'APP_DATE'])

            return df.reset_index(drop=True)

    except Exception as e:
        logger.error(f"Error in get_cleaned_inventory_data: {e}", exc_info=True)
        return pd.DataFrame()