from django.db import connection
import pandas as pd
import numpy as np
from django.shortcuts import render, redirect
import json
from inventory_app.models import get_top_items
from statsmodels.tsa.seasonal import seasonal_decompose
from .models import get_cleaned_inventory_data

import logging
logger = logging.getLogger(__name__)

def top_items_view(request):
    df = get_top_items()
    logger.debug("DataFrame shape: %s", df.shape)
    logger.debug("DataFrame head: %s", df.head().to_string())
    items = []
    decomposition_results = {}
    
    if df is None or df.empty:
        logger.warning("DataFrame is empty, no items to process")
        items = []
    else:
        df['OrderYear'] = df['OrderYear'].astype(int)
        df['OrderMonth'] = df['OrderMonth'].astype(int)
        df['Total_PAY_QTY'] = df['Total_PAY_QTY'].astype(float)
        items = df[['MT_ID', 'MT_NAME', 'OrderYear', 'OrderMonth', 'Total_PAY_QTY']].to_dict('records')
        logger.debug("Items: %s", items)
        
        df['Date'] = pd.to_datetime(df['OrderYear'].astype(str) + '-' + df['OrderMonth'].astype(str).str.zfill(2) + '-01')
        
        for mt_id in df['MT_ID'].unique():
            mt_data = df[df['MT_ID'] == mt_id][['Date', 'Total_PAY_QTY']].set_index('Date')
            idx = pd.date_range(start='2015-01-01', end='2024-12-01', freq='MS')
            mt_data = mt_data.reindex(idx, fill_value=0)
            logger.debug(f"MT_ID {mt_id} has {len(mt_data)} months of data")
            
            if len(mt_data) >= 12:
                try:
                    result = seasonal_decompose(mt_data['Total_PAY_QTY'], model='additive', period=12)
                    decomposition_results[mt_id] = {
                        'trend': result.trend.dropna().tolist(),
                        'seasonal': result.seasonal.tolist(),
                        'resid': result.resid.dropna().tolist(),
                        'dates': [d.strftime('%Y-%m') for d in mt_data.index]
                    }
                    logger.debug("Decomposition Results for MT_ID %s: %s", mt_id, decomposition_results[mt_id])
                except Exception as e:
                    logger.error(f"Decomposition error for MT_ID {mt_id}: {e}")
    
    context = {
        'items': json.dumps(items),
        'decomposition_results': json.dumps(decomposition_results)
    }
    logger.debug("Context: %s", context)
    return render(request, 'inventory_app/seasonal.html', context)


# function for dashboard 
# สร้าง logger
logger = logging.getLogger(__name__)

def get_cleaned_inventory_data(start_date='2020-01-01', end_date='2024-12-31'):
    """ดึงข้อมูลที่ผ่านการกรองและทำความสะอาดแล้ว"""
    try:
        with connection.cursor() as cursor:
            ...
    except Exception as e:
        logger.error(f"Error in get_cleaned_inventory_data: {e}")  # ✅ ตอนนี้จะทำงานได้
        return pd.DataFrame()
    
def dashboard_view(request):
    df = get_cleaned_inventory_data()

    if df.empty:
        context = {
            'total_quantity': 0,
            'total_cost': 0,
            'avg_qty_per_request': 0,
            'top_materials': {},
            'dept_spending': {},
            'monthly_usage': {},
            'avg_qty_by_material': {},
        }
        return render(request, 'inventory_app/backup.html', context)

    # แปลงประเภทข้อมูลเพิ่มเติม
    df['PAY_QTY'] = pd.to_numeric(df['PAY_QTY'], errors='coerce')
    df['MT_MONEY'] = pd.to_numeric(df['MT_MONEY'], errors='coerce')
    df['APP_DATE'] = pd.to_datetime(df['APP_DATE'], errors='coerce')

    # KPIs
    total_quantity = df['PAY_QTY'].sum()
    total_cost = df['MT_MONEY'].sum()
    avg_qty_per_request = df['PAY_QTY'].mean().round(2) if not df.empty else 0

    # Top 10 Materials Used
    top_materials = df.groupby('MT_NAME')['PAY_QTY'].sum().sort_values(ascending=False).head(10).to_dict()

    # Usage by Department
    dept_spending = df.groupby('COM_NAME')['MT_MONEY'].sum().sort_values(ascending=False).to_dict()

    # Monthly Usage Trend
    df['MonthYear'] = df['APP_DATE'].dt.to_period('M').astype(str)
    monthly_usage = df.groupby('MonthYear')['PAY_QTY'].sum().to_dict()

    # Avg Qty per Request by Material
    avg_qty_by_material = df.groupby('MT_NAME')['PAY_QTY'].mean().sort_values(ascending=False).head(10).to_dict()

    context = {
        'total_quantity': round(total_quantity, 2),
        'total_cost': round(total_cost, 2),
        'avg_qty_per_request': round(avg_qty_per_request, 2),

        'top_materials': top_materials,
        'dept_spending': dept_spending,
        'monthly_usage': monthly_usage,
        'avg_qty_by_material': avg_qty_by_material,

        'materials': sorted(df['MT_NAME'].unique().tolist()),
        'departments': sorted(df['COM_NAME'].unique().tolist())
    }

    return render(request, 'inventory_app/backup.html', context)


































# ฟังก์ชัน render
def login_view(request):
    if request.method == "POST":
        return redirect('HIS')  
    return render(request, 'inventory_app/login.html')

def base(request):
    return render(request, 'inventory_app/base.html')

def backup(request):
    return render(request, 'inventory_app/backup.html')

def MIS_page(request):
    return render(request, 'inventory_app/MIS_page.html')

def test(request):
    return render(request, 'inventory_app/test.html')

def copilot(request):
    return render(request, 'inventory_app/copilot.html')

def testtest(request):   
    return render(request, 'inventory_app/testtest.html')

def login_test(request):   
    return render(request, 'inventory_app/login_test.html')

def seasonal(request):   
    return render(request, 'inventory_app/seasonal.html')