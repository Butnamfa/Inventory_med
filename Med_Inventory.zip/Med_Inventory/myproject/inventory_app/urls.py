from django.urls import path
from . import views

urlpatterns = [
    path('', views.login_view, name='home'),
    path('login/', views.login_view, name='login'),
    path('base/', views.base, name='base'),
    path('testtest/', views.testtest, name='testtest'),
    path('login_test/', views.login_test, name='login_test'),
    path('seasonal/', views.top_items_view, name='top_items'),
    path('backup/', views.dashboard_view, name='backup'),
    path('copilot/', views.copilot, name='copilot'),
    path('MIS_page/', views.backup, name='MIS_page'),
]